package commands;

import ticket.Ticket;

public interface Adding {
    public void ticketRequest();
}
